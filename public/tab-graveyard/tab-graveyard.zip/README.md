# Tab Graveyard

Closes the tabs you were never going to read, and hands you a card of what you hoarded.

![the card](docs/card.png)

## Install (unpacked)

1. `chrome://extensions` → enable **Developer mode**
2. **Load unpacked** → pick this folder
3. Pin the tombstone to your toolbar and click it

Chrome 121+ (tab last-access times). Works in Edge and any Chromium browser.

## What it does

Open the popup and the card is already there — a preview of the tabs about to
be buried, so you see your number before you commit to anything. Press
**Bury 61 tabs** and they close, the card turns real, and an undo bar appears.

- **Copy card / Save PNG** — 720×1120 portrait, sized for a phone screenshot.
- **Undo** — brings back the whole batch, available for 10 minutes.
- **Search + Resurrect** — every buried tab stays searchable forever and comes
  back with one click. Burying never deletes anything.

Tabs that are pinned, or active in their window, are never touched.

## Files

| | |
|---|---|
| `manifest.json` | MV3. `tabs` + `storage`. No background worker, no content script. |
| `card.js` | `buildCard()` derives the card from entries; `drawCard()` paints it. One canvas render path, so the popup shows exactly the PNG you share. |
| `storage.js` | Entry schema and bury / undo / resurrect. Writes to storage *before* closing tabs. |
| `popup.js` | Tab query, burial, search, export. |
| `popup.html` / `popup.css` | One screen: card, graveyard, sticky bury bar. |

### Data shape

```js
entry = {
  id, batchId, url, title, domain, favIconUrl,
  lastAccessed,   // ms, from chrome.tabs
  buriedAt,       // ms
  ageDays,        // days untouched at time of burial
}

card = {
  mode: 'preview' | 'week' | 'all',
  count, sublabel,
  oldest: { date, ageDays, title, domain },
  topDomain: { domain, count },
  totalBuried, epitaph,
}
```

Storage is `{ graveyard: entry[], lastBatch: { batchId, count, buriedAt } }`.
`lastBatch` is the whole undo mechanism.

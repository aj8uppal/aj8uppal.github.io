// chrome.storage.local shape:
//   graveyard : Entry[]        newest first
//   lastBatch : { batchId, count, buriedAt } | null   -> powers the undo bar
//
// Entry = { id, batchId, url, title, domain, favIconUrl,
//           lastAccessed, buriedAt, ageDays, resurrectedAt? }
//
// Nothing is ever hard-deleted by burying. Resurrecting removes the entry,
// because the tab is back in the browser where it belongs.

import { domainOf } from './card.js';

const DAY = 86400000;
export const UNDO_WINDOW = 10 * 60 * 1000; // undo stays available for 10 minutes

export async function readAll() {
  const { graveyard = [], lastBatch = null } = await chrome.storage.local.get(['graveyard', 'lastBatch']);
  return { graveyard, lastBatch };
}

export function toEntry(tab, batchId, now) {
  const lastAccessed = tab.lastAccessed ?? null;
  return {
    id: crypto.randomUUID(),
    batchId,
    url: tab.url,
    title: tab.title || tab.url,
    domain: domainOf(tab.url),
    favIconUrl: tab.favIconUrl || null,
    lastAccessed,
    buriedAt: now,
    ageDays: lastAccessed ? Math.max(0, Math.floor((now - lastAccessed) / DAY)) : null,
  };
}

// Writes first, closes second. If storage fails nothing is closed.
export async function bury(tabs) {
  const now = Date.now();
  const batchId = crypto.randomUUID();
  const entries = tabs.map(t => toEntry(t, batchId, now));
  const { graveyard } = await readAll();

  await chrome.storage.local.set({
    graveyard: [...entries, ...graveyard],
    lastBatch: { batchId, count: entries.length, buriedAt: now },
  });

  const ids = tabs.map(t => t.id);
  try { await chrome.tabs.remove(ids); }
  catch (e) { console.warn('some tabs would not close', e); }

  return { batchId, count: entries.length };
}

export async function undoBatch(batchId) {
  const { graveyard } = await readAll();
  const batch = graveyard.filter(e => e.batchId === batchId);
  const failed = [];
  // Oldest-first so tabs come back roughly in the order they left.
  for (const e of [...batch].reverse()) {
    try { await chrome.tabs.create({ url: e.url, active: false }); }
    catch { failed.push(e.id); }
  }
  await chrome.storage.local.set({
    graveyard: graveyard.filter(e => e.batchId !== batchId || failed.includes(e.id)),
    lastBatch: null,
  });
  return { restored: batch.length - failed.length, failed: failed.length };
}

export async function resurrect(id) {
  const { graveyard, lastBatch } = await readAll();
  const entry = graveyard.find(e => e.id === id);
  if (!entry) return false;
  await chrome.tabs.create({ url: entry.url, active: false });
  const next = graveyard.filter(e => e.id !== id);
  const patch = { graveyard: next };
  if (lastBatch && !next.some(e => e.batchId === lastBatch.batchId)) patch.lastBatch = null;
  await chrome.storage.local.set(patch);
  return true;
}

export function dismissUndo() {
  return chrome.storage.local.set({ lastBatch: null });
}

export function undoIsLive(lastBatch) {
  return !!lastBatch && Date.now() - lastBatch.buriedAt < UNDO_WINDOW;
}

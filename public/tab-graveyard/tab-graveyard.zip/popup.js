import { buildCard, drawCard, domainOf } from './card.js';
import { readAll, bury, undoBatch, resurrect, dismissUndo, undoIsLive } from './storage.js';

const $ = id => document.getElementById(id);
const DAY = 86400000;
const nf = new Intl.NumberFormat();

const el = {
  card: $('card'), copy: $('copy'), save: $('save'), hint: $('hint'),
  search: $('search'), list: $('list'), days: $('days'), bury: $('bury'),
  undo: $('undo'), undoText: $('undoText'), undoBtn: $('undoBtn'), undoX: $('undoX'),
};

let state = { graveyard: [], lastBatch: null, candidates: [], tabs: [], noTimestamps: false };

// --- input: what is eligible to be buried -----------------------------------
// Never the active tab of a window: closing it can close the window (and this
// popup with it), and an active tab is by definition not stale.
async function loadTabs() {
  const tabs = await chrome.tabs.query({});
  state.tabs = tabs.filter(t => !t.pinned && !t.active && t.url);
  state.noTimestamps = state.tabs.length > 0 && state.tabs.every(t => t.lastAccessed == null);
}

function candidatesFor(days) {
  const cutoff = Date.now() - days * DAY;
  return state.tabs.filter(t => days === 0 || (t.lastAccessed != null && t.lastAccessed < cutoff));
}

function asPreviewEntries(tabs) {
  return tabs.map(t => ({
    domain: domainOf(t.url),
    title: t.title || t.url,
    lastAccessed: t.lastAccessed ?? null,
  }));
}

// --- render ------------------------------------------------------------------
function render() {
  const days = Number(el.days.value);
  state.candidates = candidatesFor(days);

  const data = buildCard(state.graveyard, asPreviewEntries(state.candidates));
  drawCard(el.card, data);

  el.bury.textContent = state.candidates.length
    ? `Bury ${nf.format(state.candidates.length)} ${state.candidates.length === 1 ? 'tab' : 'tabs'}`
    : 'Nothing to bury';
  el.bury.disabled = state.candidates.length === 0;

  el.hint.textContent =
    state.noTimestamps ? "Your browser isn't reporting tab access times — use “everything”."
    : data.mode === 'preview' ? 'Preview. Bury them to make it real.'
    : data.mode === 'all' ? 'Nothing buried this week — showing all time.'
    : `${nf.format(data.count)} buried in the last 7 days.`;

  renderUndo();
  renderList();
}

function renderUndo() {
  const live = undoIsLive(state.lastBatch);
  el.undo.hidden = !live;
  if (live) {
    const n = state.lastBatch.count;
    el.undoText.textContent = `${nf.format(n)} ${n === 1 ? 'tab' : 'tabs'} buried — nothing was lost.`;
  }
}

function renderList() {
  const q = el.search.value.trim().toLowerCase();
  const rows = state.graveyard
    .filter(e => !q || (e.title + ' ' + e.url).toLowerCase().includes(q))
    .slice(0, 300);

  if (!rows.length) {
    el.list.innerHTML = `<p class="empty">${
      state.graveyard.length ? 'No matching graves.'
        : 'The graveyard is empty. Nothing here is ever deleted — every buried tab stays searchable and comes back in one click.'
    }</p>`;
    return;
  }

  el.list.replaceChildren(...rows.map(e => {
    const row = document.createElement('div');
    row.className = 'row';

    const img = document.createElement('img');
    img.src = e.favIconUrl || 'data:image/gif;base64,R0lGODlhAQABAAAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw==';
    img.onerror = () => { img.style.visibility = 'hidden'; };

    const meta = document.createElement('div');
    meta.className = 'meta';
    const t = document.createElement('div');
    t.className = 't';
    t.textContent = e.title;
    t.title = e.url;
    const d = document.createElement('div');
    d.className = 'd';
    d.textContent = e.ageDays == null
      ? e.domain
      : `${e.domain} · ${nf.format(e.ageDays)}d untouched`;
    meta.append(t, d);

    const btn = document.createElement('button');
    btn.textContent = 'Resurrect';
    btn.addEventListener('click', async () => {
      btn.disabled = true;
      await resurrect(e.id);
      await refresh();
    });

    row.append(img, meta, btn);
    return row;
  }));
}

async function refresh() {
  const { graveyard, lastBatch } = await readAll();
  state.graveyard = graveyard;
  state.lastBatch = lastBatch;
  await loadTabs();
  render();
}

// --- actions -----------------------------------------------------------------
el.bury.addEventListener('click', async () => {
  const victims = state.candidates;
  if (!victims.length) return;
  el.bury.disabled = true;
  try {
    await bury(victims);
  } catch (e) {
    // Storage failed, so nothing was closed. Say so plainly.
    el.hint.textContent = 'Could not write the graveyard — no tabs were closed.';
    console.error(e);
  }
  await refresh();
});

el.undoBtn.addEventListener('click', async () => {
  const batchId = state.lastBatch?.batchId;
  if (!batchId) return;
  el.undoBtn.disabled = true;
  const { failed } = await undoBatch(batchId);
  await refresh();
  el.undoBtn.disabled = false;
  if (failed) el.hint.textContent = `${failed} tab${failed === 1 ? '' : 's'} couldn't reopen — still in the graveyard.`;
});

el.undoX.addEventListener('click', async () => { await dismissUndo(); await refresh(); });
el.days.addEventListener('change', render);
el.search.addEventListener('input', renderList);

el.save.addEventListener('click', () => {
  el.card.toBlob(blob => {
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `tab-graveyard-${new Date().toISOString().slice(0, 10)}.png`;
    a.click();
    setTimeout(() => URL.revokeObjectURL(url), 10000);
    flash(el.save, 'Saved');
  }, 'image/png');
});

el.copy.addEventListener('click', () => {
  el.card.toBlob(async blob => {
    try {
      await navigator.clipboard.write([new ClipboardItem({ 'image/png': blob })]);
      flash(el.copy, 'Copied');
    } catch {
      el.hint.textContent = 'Clipboard blocked — use Save PNG.';
    }
  }, 'image/png');
});

function flash(btn, text) {
  const original = btn.textContent;
  btn.textContent = text;
  btn.classList.add('done');
  setTimeout(() => { btn.textContent = original; btn.classList.remove('done'); }, 1400);
}

refresh();
